This is team 2 implemented this project of requirement 1

Team Name :  we all together discussed and implemented end to end(both Java with Angular)

Mulki
Kiran
Chandra sekhar
Nibedita
Satheep reddy


Developed Angular JS UI by Mulki and Kiran
Developed Java with Spring boot functionalities by Chandra , Nibedita, Satheep reddy.

working URL  http://localhost:2033/iotservice/devicelist

To run this application

import deviceRegistration2 into eclipse
1. right click on Deviceregistration2Application.java and run as java application
2. hit url in browser http://localhost:2033/iotservice/devicelist


