var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, appServices) {
  $scope.firstName= "John";
  $scope.lastName= "Doe";
  $scope.products = ["Milk", "Bread", "Cheese"];
  $scope.deviceRegistration ={};
  
  $scope.saveDeviceForm = function(){
	  
	  console.log($scope.deviceRegistration);
	  appServices.saveDeviceRegistration();
	  
  }
  
  $scope.loadDeviceForm = function(){
	  $scope.deviceRegistration ={};
	  appServices.loadDeviceRegistration();
  }
  
  

});

app.factory('appServices', function($http) {
	var baseUrl = "/iotservice";
	var endPoint = "http://localhost:2033/iotservice"
	return{
		saveDeviceRegistration :function (){
				var url = endPoint+"/devicelist"
			$http.get(url).then(function(data){
				consolo.log("data" + data);
				return data;
		});
			console.log("inside factory");
			return ;
		},
		
		loadDeviceRegistration : function(){
			var request = {};
			$http.post(url,request).then(function(data){
				return data;
			})
		}
	}
		
	});