var app = angular.module('myApp', []);
app.factory('appServices', function($scope, $http) {
	var baseUrl = "/iotservice";
	var endPoint = "http://localhost:2033/iotservice"
	return{
		saveDeviceRegistration :function (){
			var url = endPoint+"/devicelist"
			$http.get(url).then(function(data){
				consolo.log("data" + data);
		});
			console.log("inside factory");
		}
		
		
	}
	
	
	
});
