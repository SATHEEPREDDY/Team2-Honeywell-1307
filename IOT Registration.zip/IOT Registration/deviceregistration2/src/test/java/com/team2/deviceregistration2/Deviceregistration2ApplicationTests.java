package com.team2.deviceregistration2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Deviceregistration2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
