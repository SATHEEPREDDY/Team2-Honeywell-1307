package com.iot.dao;

import java.util.List;
import java.util.Map;

import com.iot.model.Account;
import com.iot.model.Device;

public interface DeviceRegisterDao {
	
	
	
	public void registerDevice(Device device);

	public List<Device> getDeviceList();
	
	public void createAccountInfo(Account account);
	
	public Map<Long,List<Device>> getAccounts();
	
	public List<Device> getAccountById( long id) ;

}
