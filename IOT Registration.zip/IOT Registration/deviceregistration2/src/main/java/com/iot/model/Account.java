package com.iot.model;

import java.util.List;

public class Account {
	
	private long accountId;
	private String accountName;
	private List<Device> devices;
	
	public Account(long accountId, String accountName, List<Device> devices) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.devices = devices;
	}
	
	
	public long getAccountId() {
		return accountId;
	}


	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public List<Device> getDevices() {
		return devices;
	}


	public void setDevices(List<Device> devices) {
		this.devices = devices;
	}


	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountName=" + accountName + ", devices=" + devices + "]";
	}


	}
