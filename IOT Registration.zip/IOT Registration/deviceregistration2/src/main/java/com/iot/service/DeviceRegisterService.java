package com.iot.service;

import java.util.List;
import java.util.Map;

import com.iot.model.Account;
import com.iot.model.Device;

public interface DeviceRegisterService {
	public void registerDevice(Device device);
	
	public void createAccountInfo(Account account);
	
	public List<Device> listDevice();
	
	public Map<Long,List<Device>> getAccounts();
	public List<Device> getAccountById( long id) ;
	

}
