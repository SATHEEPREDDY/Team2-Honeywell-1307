package com.iot.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iot.dao.DeviceRegisterDao;
import com.iot.model.Account;
import com.iot.model.Device;

@Service
public class DeviceRegisterServiceImpl implements DeviceRegisterService {
	
	@Autowired
	DeviceRegisterDao deviceDao;

	@Override
	public void registerDevice(Device device) {
		// TODO Auto-generated method stub
		deviceDao.registerDevice(device);
		
	}

	@Override
	public void createAccountInfo(Account account) {
		
		deviceDao.createAccountInfo(account);
	}

	@Override
	public List<Device> listDevice() {
		// TODO Auto-generated method stub
		return deviceDao.getDeviceList();
	}

	@Override
	public Map<Long, List<Device>> getAccounts() {
		// TODO Auto-generated method stub
		return deviceDao.getAccounts();
	}

	@Override
	public List<Device> getAccountById(long id) {
		// TODO Auto-generated method stub
		return deviceDao.getAccountById(id);
	}

	

	
	
	

}
