package com.iot.controller;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.iot.model.Account;
import com.iot.model.Device;
import com.iot.service.DeviceRegisterService;



@RestController
@RequestMapping("/iotservice")
public class DeviceReistrationController implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	private DeviceRegisterService deviceServ;
	
	 @RequestMapping(value = "/deviceinfo", method = RequestMethod.POST)
	public void registerDevice(@RequestBody Device device) {
		
		deviceServ.registerDevice(device);
		
	}
	
	 @RequestMapping(value = "/devicelist", method = RequestMethod.GET)
	
	public @ResponseBody List<Device> listDevice() {
		 List<Device> listDevice = deviceServ.listDevice();
		 System.out.println(listDevice);
		return listDevice;
		
		
	}
	
	 @RequestMapping(value = "/accountinfo", method = RequestMethod.POST)
	
	
	public void createAccountInfo(@RequestBody Account account) {
		
		 deviceServ.createAccountInfo(account);
		
	}
	
	 @RequestMapping(value = "/accountlist", method = RequestMethod.GET,
	            consumes = MediaType.APPLICATION_JSON_VALUE,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	
	public Map<Long,List<Device>> listAccounts() {
		
		return deviceServ.getAccounts();
		
		
	}
	 @RequestMapping(value = "/account/{id}", method = RequestMethod.GET)
	
	
	public List<Device> getAccountById(@PathVariable long id) {
		
		return deviceServ.getAccountById(id);
		
		
	}
	
	

}
