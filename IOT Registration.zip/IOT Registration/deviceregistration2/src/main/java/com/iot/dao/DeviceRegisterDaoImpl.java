package com.iot.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.iot.model.Account;
import com.iot.model.Device;

@Repository
public class DeviceRegisterDaoImpl  implements DeviceRegisterDao{
	
	
	private List<Device> registeredDevices=new ArrayList<Device>();
	
	private Map<Long ,List<Device>>  accountInfo;

	@Override
	public void registerDevice(Device device) {
		// TODO Auto-generated method stub
		
		registeredDevices.add(device);
		
		
	}

	@Override
	public List<Device> getDeviceList() {
		// TODO Auto-generated method stub
		Device dev1=new Device(1, "IOT1", "IOT Dev1");
		Device dev2=new Device(2, "IOT2", "IOT Dev2");
		Device dev3=new Device(3, "IOT3", "IOT Dev3");
		Device dev4=new Device(4, "IOT4", "IOT Dev4");
		Device dev5=new Device(5, "IOT5", "IOT Dev5");
		
		registeredDevices.add(dev1);
		registeredDevices.add(dev2);
		registeredDevices.add(dev3);
		registeredDevices.add(dev4);
		registeredDevices.add(dev5);
		
		return registeredDevices;
	}

	@Override
	public void createAccountInfo(Account account) {
		// TODO Auto-generated method stub
		


		
		accountInfo.put(account.getAccountId(), account.getDevices());
		
	}

	@Override
	public Map<Long, List<Device>> getAccounts() {
		// TODO Auto-generated method stub
		
		List<Device> listDevice1=new ArrayList<Device>();
//		Device dev1=new Device(1, "IOT1", "IOT Dev1");
//		Device dev2=new Device(2, "IOT2", "IOT Dev2");
//		listDevice1.add(dev1);
//		listDevice1.add(dev2);
//		
//		List<Device> listDevice2=new ArrayList<Device>();
//		Device dev3=new Device(3, "IOT3", "IOT Dev3");
//		Device dev4=new Device(4, "IOT4", "IOT Dev4");
//		listDevice2.add(dev3);
//		listDevice2.add(dev4);
//		
//		
//		
//		Account acc1=new Account(11, "Amazon",listDevice1 );
//		
//		Account acc2=new Account(22, "IBM",listDevice2 );
//		
//		
//		accountInfo=new HashMap<Long, List<Device>>();
//		
//		accountInfo.put(acc1.getAccountId(), acc1.getDevices());
//		accountInfo.put(acc2.getAccountId(), acc2.getDevices());
		
		
		
		
		
		return accountInfo;
	}

	@Override
	public List<Device> getAccountById(long id) {
		// TODO Auto-generated method stub
		List<Device> l1 = null;
		Set<Long> ids = accountInfo.keySet();
		for(Long idAcc : ids) {
			if(idAcc == id) {
				l1 = new ArrayList<Device>();
				l1 = accountInfo.get(idAcc);
			}
		}
		
		return l1;
	}
	
	

	
}
