package com.iot.model;

import java.io.Serializable;

public class Device implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4079061459275097616L;
	
	
	private long id;
	private String name;
	private String description;
	
	public Device(long id, String name, String description) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "DeviceInfo [id=" + id + ", name=" + name + ", description=" + description + "]";
	}

	
	
}
